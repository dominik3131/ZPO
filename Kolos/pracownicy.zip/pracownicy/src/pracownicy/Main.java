
package pracownicy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Main {
    public List<Pracownik> allWorkers;
    public Pracownik boss;
    public Main(){
        allWorkers=new ArrayList<>();
        
    }
    public static void main(String[] args) throws IOException{
        Main m=new Main();
        m.loadWorkers();
        
        m.printTree();
        Pracownik szymon,wojciech,dominik,lidia;
        szymon=m.allWorkers.get(m.allWorkers.indexOf(new Pracownik("Szymon Grabowski")));
        wojciech=m.allWorkers.get(m.allWorkers.indexOf(new Pracownik("Wojciech Bieniecki")));
        //dominik=m.allWorkers.get(m.allWorkers.indexOf(new Pracownik("Dominik Sankowski")));
        //lidia=m.allWorkers.get(m.allWorkers.indexOf(new Pracownik("Lidia Jackowska-Strumillo")));
        szymon.printSubordinates(0);
        
        
    }
    
    public void loadWorkers() throws IOException{
        Path p=FileSystems.getDefault().getPath("osoby.txt");
        List<String> tempList = Files.readAllLines(p, StandardCharsets.UTF_8);
        for(String line : tempList){
            String[] tmp = line.split(",");
            Pracownik w,s;
            if(tmp[1].trim().equals("null")){
                boss = new Pracownik(tmp[0].trim());
                if(!allWorkers.contains(boss)) allWorkers.add(boss);
            }
            else{
                
                s = new Pracownik(tmp[1].trim());
                
                if(allWorkers.contains(s)){
                    s=allWorkers.get(allWorkers.indexOf(s));
                }
                else{
                   
                }
                w= new Pracownik(tmp[0].trim());
              
                w.setSupervisor(s);
                s.addSubordinate(w);
                allWorkers.add(w);
                 allWorkers.add(s);
            }
            
        }
    }
    public void printTree(){
        boss=allWorkers.get(allWorkers.indexOf(boss));
        boss.printSubordinates(0);
    }
    
    
    
   
}
