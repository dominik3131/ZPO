package refleksja;

import java.io.IOException;
import javax.lang.model.element.Element;
import javax.swing.text.Document;

/**
 *
 * @author Dominik
 */
public class NewClass {

    public static void main(String[] args) throws IOException {
        
    }
}
